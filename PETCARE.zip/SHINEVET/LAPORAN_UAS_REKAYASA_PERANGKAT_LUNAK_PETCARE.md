# STMIK IKMI CIREBON
## LEMBAR JAWABAN UJIAN AKHIR SEMESTER (UAS)
**Mata Kuliah** : Rekayasa Perangkat Lunak  
**Program Studi** : Rekayasa Perangkat Lunak (S1)  
**Dosen Pengampu**: Agus Bahtiar, M.Kom.  
**Jenis Ujian**   : Praktikum / Projek  

---

## A. IDENTITAS MAHASISWA

- **Nama Mahasiswa** : [Nama Mahasiswa] *(Dapat disesuaikan)*
- **NIM**            : [NIM Mahasiswa] *(Dapat disesuaikan)*
- **Kelas / Semester**: RPL-S1 / Semester [Sesuai KRS]
- **Tanggal Ujian**  : [Tanggal Ujian / 11 November 2026]
- **Judul Projek**   : **PETCARE - Sistem Informasi Rekam Medis dan Manajemen Jadwal Vaksinasi Hewan Berbasis Web pada Klinik Dokter Hewan Kota Cirebon**

---

## B. JAWABAN UJIAN

### 1. Ringkasan Studi Kasus dan Kebutuhan Sistem

#### a. Deskripsi Studi Kasus dan Permasalahan
Klinik dokter hewan mandiri dan praktik bersama di Kota Cirebon menghadapi tantangan dalam pengelolaan administrasi medis dan pelayanan pasien hewan peliharaan (*pet animal*). Berdasarkan observasi studi kasus, beberapa permasalahan utama yang diidentifikasi meliputi:
1. **Pencatatan Rekam Medis Masih Terfragmentasi**: Riwayat pemeriksaan fisik, diagnosa, dan terapi obat sering kali dicatat pada kartu status fisik manual atau lembaran kertas yang rentan sobek, hilang, tercecer, dan sulit ditelusuri riwayat kronologisnya saat hewan mengalami kondisi darurat.
2. **Keterlambatan dan Kelalaian Jadwal Vaksinasi Berkala**: Pemilik hewan kerap lupa tanggal jatuh tempo vaksinasi tahunan (seperti Vaksin Rabies, DHPPi, dan FVRCP/Tricat). Akibatnya, kekebalan imunitas hewan menurun drastis dan risiko penularan penyakit zoonosis meningkat.
3. **Pemesanan Janji Temu Rentan Bentrok (*Schedule Collision*)**: Pendaftaran kunjungan via pesan teks konvensional tanpa sistem ketersediaan slot waktu sering kali menimbulkan penumpukan pasien di ruang tunggu (*overcrowded*) serta jadwal bentrok antar-pasien pada jam praktik dokter yang sama.
4. **Resepsionis dan Dokter Kurang Memiliki Visibilitas Operasional**: Petugas klinik kesulitan memonitor secara terpusat pasien mana saja yang janji temunya menunggu verifikasi, telah dikonfirmasi, maupun yang membutuhkan pembuatan rekam medis pasca-pemeriksaan.

#### b. Tujuan Pengembangan Aplikasi
Tujuan dari pengembangan sistem informasi **PETCARE** adalah:
1. Membangun platform web terintegrasi yang mampu mendigitalkan rekam medis hewan secara kronologis, akurat, dan dapat dicetak sewaktu-waktu sebagai lembar rekam medis resmi.
2. Menyediakan modul kalender vaksinasi interaktif yang menghitung status jatuh tempo secara dinamis berdasarkan tanggal sistem aktual (*Terlewat, X hari lagi, Selesai*).
3. Mengembangkan modul reservasi janji temu melalui mekanisme *3-step booking wizard* yang dilengkapi algoritma pencegahan jadwal ganda (*slot collision prevention*) secara *real-time*.
4. Mengimplementasikan *Meja Kelola Janji Temu Admin (Admin Appointment Desk)* yang memfasilitasi verifikasi jadwal, penunjukan dokter penanggung jawab, alokasi ruangan pemeriksaan, serta integrasi pesan konfirmasi WhatsApp langsung kepada pemilik hewan.

---

#### c. Kebutuhan Fungsional (Functional Requirements)

| No. | Kode Kebutuhan | Kebutuhan Fungsional | Deskripsi Fungsi |
| :---: | :---: | :--- | :--- |
| 1 | **SKF-01** | **Autentikasi & Otorisasi Pengguna (*Role-Based*)** | Sistem mampu mengotentikasi pengguna dengan enkripsi password aman, serta membedakan hak akses antara peran Klien/Pemilik Hewan (*Client*) dan Dokter Hewan/Admin (*Vet/Admin*). |
| 2 | **SKF-02** | **Manajemen Data Hewan Pasien (*CRUD Pets*)** | Sistem menyediakan fitur tambah, lihat profil lengkap, perbarui, dan hapus data hewan (nama, foto HD, jenis/spesies, ras, kelamin, tanggal lahir, berat badan, ciri khusus, alergi, dan kode unik rekam medis). |
| 3 | **SKF-03** | **Pengelolaan Rekam Medis Digital (*Medical Records*)** | Sistem mencatat dan menampilkan riwayat rekam medis terhubung dengan pasien (tanggal periksa, keluhan awal, pemeriksaan fisik, diagnosa, tindakan medis, resep obat, catatan dokter, dan jadwal kontrol berikutnya). |
| 4 | **SKF-04** | **Cetak Lembar Rekam Medis (*Printable Medical Slip*)** | Sistem menyediakan fitur cetak langsung (*print view*) lembar resmi rekam medis hewan berkop resmi PETCARE Cirebon. |
| 5 | **SKF-05** | **Manajemen Jadwal Vaksinasi & Kalender Interaktif** | Sistem menyediakan kalender interaktif bulanan dengan penanda tanggal vaksin, filter status, dan perhitungan selisih hari aktual secara otomatis (*Terlewat, Mendekat/X hari lagi, Selesai*). |
| 6 | **SKF-06** | **Tandai Selesai Vaksinasi (*Quick Complete*)** | Sistem memungkinkan dokter/admin mengubah status vaksinasi terjadwal menjadi "Selesai" secara instan dengan satu kali klik. |
| 7 | **SKF-07** | **Reservasi Janji Temu Pasien (*3-Step Wizard*)** | Sistem memfasilitasi pemilik hewan memesan jadwal melalui 3 tahapan terarah: Pilih Layanan, Pilih Tanggal & Waktu, dan Pilih Pasien serta Keluhan. |
| 8 | **SKF-08** | **Pencegahan Slot Waktu Ganda (*Collision Prevention*)** | Sistem secara otomatis menonaktifkan (*disable*) tombol slot jam kunjungan pada tanggal tertentu yang telah dipesan oleh pasien lain. |
| 9 | **SKF-09** | **Meja Kelola Janji Temu Admin (*Admin Desk*)** | Sistem menyediakan dasbor operasional admin untuk meninjau pengajuan janji temu masuk, menetapkan dokter penanggung jawab, menentukan ruangan, atau menjadwal ulang (*reschedule*). |
| 10 | **SKF-10** | **Integrasi Konfirmasi WhatsApp Otomatis** | Sistem mengonversi data janji temu yang terkonfirmasi menjadi draf pesan WhatsApp resmi yang siap dikirimkan langsung ke nomor ponsel pemilik. |
| 11 | **SKF-11** | **Mesin Pengingat Otomatis (*Reminders Engine*)** | Sistem mendeteksi dan menampilkan daftar notifikasi jatuh tempo vaksinasi serta rekomendasi tanggal kontrol ulang dokter berdasarkan parameter urgensi. |
| 12 | **SKF-12** | **Dasbor Ringkasan & Pencarian Cepat (*Global Search*)** | Sistem menyajikan statistik total hewan, vaksin aktif, janji temu mendatang, linimasa aktivitas terbaru, serta fitur pencarian global. |

---

#### d. Kebutuhan Nonfungsional (Non-Functional Requirements)

| No. | Parameter | Kebutuhan Nonfungsional | Spesifikasi Teknis & Bukti Implementasi |
| :---: | :--- | :--- | :--- |
| 1 | **Usability** | Antarmuka pengguna harus intuitif, bersih, ramah pengguna, dan responsif di laptop, tablet, dan smartphone. | Menggunakan CSS modern (*Plus Jakarta Sans*, palet warna `#1769E8` & `#EFF6FF`), sudut membulat 16px, hierarki visual jelas, dan waktu adaptasi pengguna baru < 3 menit. |
| 2 | **Performance** | Waktu muat (*page load*) halaman dan eksekusi operasi CRUD tidak boleh lebih dari 1.5 detik. | Menggunakan arsitektur *Single Page Application (SPA)* lokal dengan *caching localStorage* dan API asynchronous ringan tanpa beban *re-render* penuh halaman. |
| 3 | **Reliability & Availability** | Sistem harus mampu beroperasi secara mandiri (*offline-first capability*) dan tahan terhadap kegagalan koneksi database. | Dual-layer persistence: Data tersimpan persisten pada *localStorage* klien dan otomatis tersinkronisasi ke basis data MySQL (PDO) apabila server backend aktif. |
| 4 | **Security** | Keamanan data transaksi, proteksi formulir dari injeksi skrip, dan penyimpanan kata sandi terenkripsi. | Password dienkripsi dengan algoritma `BCRYPT`, query SQL backend menerapkan `PDO Prepared Statements`, validasi input formulir client-side & server-side, serta sanitasi karakter HTML. |
| 5 | **Portability & Maintainability** | Kode harus terstruktur modular, mudah dirawat, dan kompatibel dengan lingkungan web standar. | Pemisahan fungsionalitas modular (`store.js`, `pets.js`, `medical-records.js`, `appointments.js`, `vaccinations.js`), serta struktur server XAMPP Apache/PHP 8.x standar. |

---

### 2. Pemodelan UML (Unified Modeling Language)

#### a. Use Case Diagram

```mermaid
flowchart LR
  subgraph Aktor
    Client(("Pemilik Hewan<br>(Klien)"))
    Admin(("Dokter Hewan /<br>Admin"))
  end

  subgraph Sistem_PETCARE ["Sistem Informasi PETCARE"]
    UC1(["Melakukan Autentikasi / Login & Registrasi"])
    UC2(["Melihat Profil & Layanan Klinik"])
    UC3(["Mengelola Data Hewan Pasien (CRUD)"])
    UC4(["Mengajukan Janji Temu (3-Step Wizard)"])
    UC5(["Melihat Riwayat & Cetak Rekam Medis"])
    UC6(["Melihat Kalender & Notifikasi Pengingat Vaksin"])
    UC7(["Memvalidasi / Konfirmasi Janji Temu Pasien"])
    UC8(["Mengirim Konfirmasi via WhatsApp Direct"])
    UC9(["Menjadwal Ulang (Reschedule) Kunjungan"])
    UC10(["Mencatat & Memperbarui Rekam Medis"])
    UC11(["Memperbarui Status Jadwal Vaksinasi"])
  end

  Client --> UC1
  Client --> UC2
  Client --> UC3
  Client --> UC4
  Client --> UC5
  Client --> UC6

  Admin --> UC1
  Admin --> UC3
  Admin --> UC5
  Admin --> UC6
  Admin --> UC7
  Admin --> UC8
  Admin --> UC9
  Admin --> UC10
  Admin --> UC11
```

*Penjelasan*:
- **Aktor Klien**: Melakukan pendaftaran akun, mengelola profil hewan peliharaan mereka, mengajukan reservasi kunjungan, melihat histori rekam medis & mencetaknya, serta memantau kalender vaksin.
- **Aktor Dokter Hewan / Admin**: Memiliki hak akses terhadap seluruh data pasien, memvalidasi janji temu yang masuk, menghubungi pemilik via WhatsApp, menginput diagnosa rekam medis baru, dan memperbarui status vaksinasi.

---

#### b. Activity Diagram: Alur Pemesanan Janji Temu & Konfirmasi Admin

```mermaid
flowchart TD
  Start([Mulai]) --> PilihLayanan[Klien memilih jenis layanan medis]
  PilihLayanan --> PilihJadwal[Klien memilih tanggal & slot jam]
  PilihJadwal --> CekBentrok{Apakah slot jam<br>sudah dipesan?}
  CekBentrok -- Ya --> SlotDisable[Slot dinonaktifkan / Tampil peringatan]
  SlotDisable --> PilihJadwal
  CekBentrok -- Tidak --> PilihPasien[Pilih hewan & masukkan keluhan awal]
  PilihPasien --> SubmitAppt[Klien klik 'Konfirmasi & Ajukan Janji']
  SubmitAppt --> SimpanMenunggu[Sistem menyimpan status 'Menunggu Konfirmasi']
  SimpanMenunggu --> NotifAdmin[Admin menerima notifikasi pengajuan baru]
  NotifAdmin --> BukaAdminDesk[Admin membuka Meja Kelola Janji Temu]
  BukaAdminDesk --> KeputusanAdmin{Konfirmasi /<br>Jadwal Ulang?}
  KeputusanAdmin -- Konfirmasi --> TetapkanDokter[Tentukan dokter jaga & ruangan]
  TetapkanDokter --> UpdateStatusKonfirm[Status berubah menjadi 'Dikonfirmasi']
  UpdateStatusKonfirm --> KirimWA[Generate & kirim draf konfirmasi WhatsApp]
  KeputusanAdmin -- Jadwal Ulang --> Reschedule[Ubah tanggal/jam baru sesuai kesepakatan]
  Reschedule --> KirimWA
  KirimWA --> Selesai([Selesai])
```

---

#### c. Sequence Diagram: Interaksi Reservasi & Konfirmasi Janji Temu

```mermaid
sequenceDiagram
  autonumber
  actor User as Pemilik Hewan
  participant UI as Browser (Antarmuka)
  participant App as Controller (appointments.js)
  participant Store as Data Store (store.js / API)
  actor Admin as Admin / Dokter

  User->>UI: Pilih Layanan, Tanggal & Jam (Pukul 11:00)
  UI->>App: selectTime("11:00")
  App->>Store: isSlotBooked(date, "11:00")
  Store-->>App: false (Slot Tersedia)
  App-->>UI: Tandai slot aktif & aktifkan tombol Lanjutkan
  User->>UI: Pilih Pasien Hewan & Klik "Konfirmasi & Ajukan Janji"
  UI->>App: submitBooking()
  App->>Store: saveAppointment(data, status: "Menunggu Konfirmasi")
  Store-->>UI: Respon Berhasil & Tampilkan Notifikasi Toast
  
  Note over UI,Admin: Admin Membuka Meja Kelola Janji Temu
  Admin->>UI: Klik Tombol "Terima & Konfirmasi"
  UI->>App: openAdminConfirmModal(apptId)
  Admin->>UI: Pilih dr. Sari Wijaya, Ruang Periksa 1 & Simpan
  UI->>App: submitAdminConfirmation()
  App->>Store: confirmAppointment(id, dokter, ruangan, catatan)
  Store-->>UI: Status berubah menjadi 'Dikonfirmasi'
  UI-->>Admin: Buka tautan draf konfirmasi WhatsApp ke Pemilik
```

---

#### d. Class Diagram Struktur Perangkat Lunak

```mermaid
classDiagram
  class User {
    +int id
    +string username
    +string email
    +string password
    +string full_name
    +string phone
    +string address
    +string role
    +string avatar
    +login()
    +register()
  }

  class Pet {
    +int id
    +int user_id
    +string pet_code
    +string name
    +string species
    +string breed
    +string gender
    +date birth_date
    +float weight
    +string color_marks
    +string allergy_notes
    +string photo_url
    +string status
    +save()
    +delete()
  }

  class MedicalRecord {
    +int id
    +int pet_id
    +string doctor_name
    +date exam_date
    +string service_type
    +string complaints
    +string physical_exam
    +string diagnosis
    +string treatment
    +string medicine
    +string notes
    +date next_control_date
    +save()
    +printSlip()
  }

  class Vaccination {
    +int id
    +int pet_id
    +string vaccine_name
    +string batch_number
    +date administered_date
    +date next_due_date
    +string doctor_name
    +string status
    +string notes
    +calculateDaysRemaining()
    +markCompleted()
  }

  class Appointment {
    +int id
    +int user_id
    +int pet_id
    +string service_type
    +date appointment_date
    +string appointment_time
    +string complaints
    +string status
    +string assigned_doctor
    +string assigned_room
    +string admin_notes
    +checkSlotClash()
    +confirm()
    +reschedule()
  }

  User "1" --> "0..*" Pet : memiliki
  User "1" --> "0..*" Appointment : mengajukan
  Pet "1" --> "0..*" MedicalRecord : memiliki catatan
  Pet "1" --> "0..*" Vaccination : memiliki jadwal
  Pet "1" --> "0..*" Appointment : diperiksa dalam
```

---

### 3. Rancangan Basis Data (Entity Relationship Diagram)

#### a. Entitas dan Atribut Utama
1. **Entitas `users`**: Menyimpan identitas pengguna (pemilik hewan, dokter hewan, dan staf admin).
   - Atribut: `id` (PK, INT AUTO_INCREMENT), `username` (VARCHAR 50, UNIQUE), `email` (VARCHAR 100, UNIQUE), `password` (VARCHAR 255), `full_name` (VARCHAR 100), `phone` (VARCHAR 25), `address` (TEXT), `role` (ENUM: 'client', 'vet', 'admin'), `avatar` (VARCHAR 255), `created_at` (TIMESTAMP).
2. **Entitas `pets`**: Menyimpan rekam identitas profil hewan pasien.
   - Atribut: `id` (PK, INT AUTO_INCREMENT), `user_id` (FK, INT), `pet_code` (VARCHAR 20, UNIQUE), `name` (VARCHAR 60), `species` (VARCHAR 30), `breed` (VARCHAR 60), `gender` (ENUM: 'Jantan', 'Betina'), `birth_date` (DATE), `weight` (DECIMAL 5,2), `color_marks` (VARCHAR 150), `allergy_notes` (TEXT), `photo_url` (VARCHAR 255), `status` (ENUM: 'Aktif', 'Nonaktif').
3. **Entitas `medical_records`**: Menyimpan catatan riwayat pemeriksaan medis hewan.
   - Atribut: `id` (PK, INT AUTO_INCREMENT), `pet_id` (FK, INT), `doctor_name` (VARCHAR 100), `exam_date` (DATE), `service_type` (VARCHAR 100), `complaints` (TEXT), `physical_exam` (TEXT), `diagnosis` (VARCHAR 255), `treatment` (TEXT), `medicine` (TEXT), `notes` (TEXT), `next_control_date` (DATE).
4. **Entitas `vaccinations`**: Menyimpan jadwal dan riwayat pelaksanaan vaksinasi berkala.
   - Atribut: `id` (PK, INT AUTO_INCREMENT), `pet_id` (FK, INT), `vaccine_name` (VARCHAR 100), `batch_number` (VARCHAR 50), `administered_date` (DATE), `next_due_date` (DATE), `doctor_name` (VARCHAR 100), `status` (ENUM: 'Terjadwal', 'Selesai', 'Terlewat', 'Dibatalkan'), `notes` (TEXT).
5. **Entitas `appointments`**: Menyimpan jadwal reservasi kunjungan klinik.
   - Atribut: `id` (PK, INT AUTO_INCREMENT), `user_id` (FK, INT), `pet_id` (FK, INT NULL), `service_type` (VARCHAR 100), `appointment_date` (DATE), `appointment_time` (VARCHAR 10), `complaints` (TEXT), `status` (ENUM: 'Menunggu Konfirmasi', 'Dikonfirmasi', 'Selesai', 'Dibatalkan'), `admin_notes` (TEXT), `created_at` (TIMESTAMP).

#### b. Relasi Antarentitas
- Satu Pengguna (*User*) dapat memiliki banyak Hewan Peliharaan (*Pets*) [1 : N].
- Satu Pengguna (*User*) dapat membuat banyak Janji Temu (*Appointments*) [1 : N].
- Satu Hewan Peliharaan (*Pet*) dapat memiliki banyak Rekam Medis (*Medical Records*) [1 : N].
- Satu Hewan Peliharaan (*Pet*) dapat memiliki banyak Jadwal Vaksinasi (*Vaccinations*) [1 : N].
- Satu Hewan Peliharaan (*Pet*) dapat dikaitkan dengan banyak Janji Temu (*Appointments*) [1 : N].

#### c. Lampiran Diagram ERD (Entity Relationship Diagram)

```mermaid
erDiagram
  USERS ||--o{ PETS : owns
  USERS ||--o{ APPOINTMENTS : books
  PETS ||--o{ MEDICAL_RECORDS : has
  PETS ||--o{ VACCINATIONS : receives
  PETS ||--o{ APPOINTMENTS : participates_in

  USERS {
    int id PK
    string username UK
    string email UK
    string password
    string full_name
    string phone
    string role
  }

  PETS {
    int id PK
    int user_id FK
    string pet_code UK
    string name
    string species
    string breed
    decimal weight
    string status
  }

  MEDICAL_RECORDS {
    int id PK
    int pet_id FK
    string doctor_name
    date exam_date
    string diagnosis
    text treatment
    text medicine
    date next_control_date
  }

  VACCINATIONS {
    int id PK
    int pet_id FK
    string vaccine_name
    date administered_date
    date next_due_date
    string status
  }

  APPOINTMENTS {
    int id PK
    int user_id FK
    int pet_id FK
    date appointment_date
    string appointment_time
    string status
    text admin_notes
  }
```

---

### 4. Rancangan Arsitektur dan Antarmuka UI/UX

#### a. Arsitektur Aplikasi dan Teknologi yang Digunakan
Sistem informasi **PETCARE** menggunakan arsitektur **Hybrid Client-Server / Local-First Single Page Application (SPA)** dengan RESTful API:
1. **Presentation Layer (Frontend)**: Menggunakan HTML5 murni, CSS3 kustom dengan sistem variabel CSS, dan JavaScript modern ES6+ berbasis modul. Berjalan langsung di sisi peramban (*client browser*) dengan performa rendering instan.
2. **Data & State Management Layer**: Modul `store.js` bertindak sebagai *Local State Engine* yang menjamin ketersediaan data secara persisten melalui `localStorage` peramban.
3. **Application & Service Layer (Backend)**: Menggunakan bahasa pemrograman PHP versi 8.2 yang menyediakan antarmuka REST API JSON untuk modul Autentikasi (`api/auth.php`), Hewan (`api/pets.php`), Rekam Medis (`api/records.php`), Vaksinasi (`api/vaccinations.php`), dan Janji Temu (`api/appointments.php`).
4. **Data Persistence Layer (Database)**: Basis data relasional MySQL/MariaDB yang dikoneksikan melalui pustaka PHP Data Objects (PDO) dengan *Prepared Statements*.

#### b. Rancangan Antarmuka Aplikasi
Aplikasi mengadopsi 9 tampilan utama sesuai spesifikasi mockup:
1. **Beranda (*Landing Page*)**: Bilah navigasi, hero section dengan foto anjing & kucing berkualitas HD, tombol *Call-to-Action*, 3 kartu keunggulan klinik, dan rangkuman layanan.
2. **Tentang Kami**: Profil lengkap klinik PETCARE di Kota Cirebon (Jl. Terusan Cipto No. 8), foto gedung klinik HD, jam operasional (09.00 - 19.00 WIB), dan kartu keunggulan.
3. **Layanan Medis**: Grid 3x2 kartu layanan komprehensif (Pemeriksaan Umum, Vaksinasi, Sterilisasi & Kastrasi, Pengobatan Penyakit, Perawatan Gigi, Rawat Inap).
4. **Halaman Masuk & Pendaftaran (*Auth*)**: Formulir login dan registrasi dengan pemilih akun demo satu-klik (*Nasywa sebagai Klien, dr. Sari sebagai Dokter/Admin*).
5. **Dashboard Overview**: 3 kartu ringkasan KPI (Total Hewan, Jadwal Vaksin, Pemeriksaan Terdekat), daftar vaksin terdekat, dan linimasa aktivitas terbaru.
6. **Profil & Data Hewan (*Pets Management*)**: Tampilan profil hewan utama (Mochi, Luna, Oreo) dengan kartu identitas, tab internal (*Informasi, Rekam Medis, Vaksinasi*), filter spesies, pencarian, dan formulir CRUD modal.
7. **Rekam Medis (*Medical Records*)**: Tabel kronologis rekam medis, filter per hewan, kotak pencarian diagnosa, modal detail riwayat, dan fitur cetak slip (*Print Slip*).
8. **Jadwal Vaksinasi (*Vaccination Calendar*)**: Tampilan kalender interaktif bulanan dengan penanda tanggal titik serta daftar vaksinasi yang dilengkapi lencana status dinamis berdasarkan tanggal sistem.
9. **Meja Kelola Janji Temu Admin (*Admin Appointment Desk*)**: Dasbor status tiket pemesanan, verifikasi persetujuan dokter, alokasi ruangan periksa, pengubah jadwal (*reschedule*), integrasi tombol WhatsApp pemilik, serta formulir pemesanan 3 langkah bagi pasien.

#### c. Alasan Pemilihan Rancangan
- **Psikologi Warna Medis**: Warna utama biru royal (`#1769E8`) dipilih untuk membangun rasa percaya (*trust*), profesionalisme, dan ketenangan bagi pemilik hewan yang sedang cemas. Warna sekunder biru muda pastel (`#EFF6FF`) dan latar belakang abu-abu sangat muda (`#F8FAFC`) memberikan kesan bersih, higienis, dan modern.
- **Kemudahan Aksesibilitas (*High Readability*)**: Menggunakan tipografi *Plus Jakarta Sans* dengan kontras rasio tinggi memenuhi standar WCAG (Web Content Accessibility Guidelines).
- **Desain Kartu (*Card-based Layout*) & Responsive Grid**: Memberikan pemisahan informasi yang rapi, modular, dan dapat beradaptasi secara fleksibel di layar *smartphone*, tablet, maupun desktop saat dokter hewan melakukan inspeksi langsung di ruang periksa.

---

### 5. Implementasi Aplikasi

#### a. Framework dan Teknologi yang Digunakan
- **Struktur Halaman**: HTML5 Semantic Markup
- **Tata Letak & Gaya**: CSS3 Modern (Custom Variables, Flexbox, CSS Grid)
- **Logika & Interaktivitas**: Vanilla JavaScript Modern (ES6+ Modular)
- **Bahasa Sisi Server**: PHP 8.2 (RESTful Architecture & Session Handler)
- **Basis Data**: MySQL 8.0 / MariaDB (Engine InnoDB)
- **Koneksi Database**: PDO (*PHP Data Objects*) dengan *Prepared Statements*
- **Lingkungan Pengembangan**: XAMPP Server (Apache, PHP, MySQL), Git Version Control

#### b. Fitur Utama yang Diimplementasikan

| No. | Nama Fitur | Status Implementasi | Keterangan |
| :---: | :--- | :---: | :--- |
| 1 | Autentikasi Pengguna & Role Switcher | **100% Berjalan** | Login, registrasi pengguna, enkripsi password, dan tombol pengalih mode (*Klien ⇄ Admin*). |
| 2 | CRUD Data Hewan Pasien | **100% Berjalan** | Tambah, ubah, detail profil komprehensif, pencarian nama hewan, dan dialog konfirmasi hapus. |
| 3 | Pengelolaan Rekam Medis Digital | **100% Berjalan** | Pencatatan diagnosa medis, riwayat kronologis per hewan, pencarian, dan cetak slip periksa resmi. |
| 4 | Kalender Vaksinasi & Status Dinamis | **100% Berjalan** | Kalender interaktif bulan berjalan, kalkulasi selisih hari aktual (*Terlewat, X hari lagi, Selesai*). |
| 5 | Booking Wizard Janji Temu (3-Step) | **100% Berjalan** | Alur pemesanan terarah dengan seleksi layanan, tanggal, jam kunjungan, dan pasien. |
| 6 | Pencegahan Pemesanan Ganda (*Collision*) | **100% Berjalan** | Slot waktu yang sudah dibooking otomatis dinonaktifkan untuk mencegah jadwal tabrakan. |
| 7 | Meja Kelola Janji Temu Admin (*Admin Desk*)| **100% Berjalan** | Konfirmasi jadwal, penunjukan dokter penanggung jawab, alokasi ruangan, dan penjadwalan ulang. |
| 8 | Integrasi WhatsApp Direct Konfirmasi | **100% Berjalan** | Satu klik untuk membuka obrolan WhatsApp pemilik dengan draf konfirmasi jadwal kunjungan. |
| 9 | Mesin Pengingat Otomatis (*Reminders*) | **100% Berjalan** | Notifikasi dinamis berdasarkan tanggal jatuh tempo vaksin dan kontrol dokter. |
| 10 | Dasbor Statistik & Pencarian Cepat | **100% Berjalan** | Penghitung KPI real-time (*hewan, vaksin, janji temu*) dan modal pencarian global. |

#### c. Tautan Repository atau Berkas Aplikasi
- **Direktori Proyek Lokal**: `C:\xampp\htdocs\SHINEVET\`
- **URL Akses Lokal Apache**: `http://localhost/SHINEVET/` atau `http://localhost/SHINEVET/index.php`
- **Akses Langsung Browser**: `file:///C:/xampp/htdocs/SHINEVET/index.html`
- **Berkas Basis Data**: `C:\xampp\htdocs\SHINEVET\database.sql`
- **Tautan Repositori Git**: `https://github.com/mahasiswa/petcare-animal-clinic` *(Dapat disesuaikan)*

---

### 6. Pengujian Perangkat Lunak (Software Testing)

Metode pengujian yang diterapkan adalah **Black Box Testing** untuk menguji fungsionalitas sistem terhadap kebutuhan fungsional tanpa melihat struktur internal kode.

#### a. Skenario dan Hasil Pengujian

| No. | Skenario Pengujian | Hasil yang Diharapkan | Hasil Aktual | Status |
| :---: | :--- | :--- | :--- | :---: |
| 1 | Membuka halaman login dan mengklik tombol demo "Klien (Nasywa)". | Sistem mengotentikasi pengguna, memperbarui sesi, dan mengarahkan ke dasbor klien. | Pengguna berhasil masuk sebagai Nasywa, antarmuka beralih ke mode klien. | **VALID** |
| 2 | Menambahkan data hewan baru tanpa mengisi kolom wajib "Nama Hewan". | Sistem menampilkan notifikasi peringatan (*danger toast*) dan memblokir proses simpan. | Muncul notifikasi "Nama hewan wajib diisi!", form tidak tersimpan. | **VALID** |
| 3 | Mengisi formulir data hewan secara lengkap dan menekan tombol simpan. | Sistem menyimpan data, menghasilkan kode unik `SV-xxxx`, dan menampilkan di daftar hewan. | Data tersimpan, kode `SV-0004` terbuat, kartu profil hewan muncul di antarmuka. | **VALID** |
| 4 | Memilih slot jam 11:00 pada tanggal yang telah dipesan oleh pasien lain. | Tombol jam 11:00 berstatus dinonaktifkan (*disabled*) dan bertuliskan "(Penuh)". | Tombol jam tidak dapat diklik dan berpenanda "(Penuh)". Pemesanan ganda tercegah. | **VALID** |
| 5 | Mengajukan janji temu baru pada slot jam yang masih tersedia. | Sistem menyimpan janji temu dengan status awal "Menunggu Konfirmasi". | Janji temu berhasil diajukan dengan lencana status kuning "Menunggu Konfirmasi". | **VALID** |
| 6 | Membuka Meja Kelola Janji Temu Admin dan mengonfirmasi janji temu pasien. | Muncul modal penetapan dokter & ruangan, status berubah menjadi "Dikonfirmasi". | Status terupdate menjadi "Dikonfirmasi", nama dokter dan ruangan tercatat rapi. | **VALID** |
| 7 | Mengklik tombol "💬 Hubungi WA" pada baris janji temu terkonfirmasi. | Sistem membuka tab baru ke tautan WhatsApp API dengan draf pesan konfirmasi otomatis. | Tautan WhatsApp terbuka dengan nomor ponsel pemilik dan teks jadwal lengkap terisi. | **VALID** |
| 8 | Mengubah tanggal sistem untuk menguji perhitungan status jadwal vaksinasi. | Sistem mengkalkulasi selisih hari aktual (menampilkan "Terlewat" jika minus, atau "X hari lagi"). | Lencana status vaksin otomatis berubah warna merah "Terlewat" atau oranye "X hari lagi". | **VALID** |
| 9 | Menekan tombol "✓ Selesai" pada salah satu daftar vaksinasi terjadwal. | Status vaksinasi langsung terupdate menjadi "Selesai" dengan lencana hijau/biru. | Status berubah menjadi "Selesai" seketika dan lencana terupdate. | **VALID** |
| 10 | Membuka modal detail rekam medis dan menekan tombol cetak slip periksa. | Muncul jendela pratinjau cetak (*print dialog*) dengan tata letak dokumen kop PETCARE. | Jendela dialog cetak peramban muncul dengan format lembar rekam medis rapi. | **VALID** |

#### b. Kesalahan yang Ditemukan dan Penanganannya
1. **Masalah Pemesanan Ganda (*Double Booking*)**:
   - *Temuan*: Pada rancangan awal, klien dapat memilih jam yang sama jika dua klien membuka form pada saat bersamaan.
   - *Penanganan*: Dibuat fungsi validator `Store.isSlotBooked(date, time)` yang secara reaktif memeriksa basis data sebelum jam dapat dipilih, serta memberikan atribut `disabled` pada elemen antarmuka slot yang telah terisi.
2. **Masalah Perhitungan Tanggal Vaksin Statis**:
   - *Temuan*: Jika tanggal vaksin ditulis tetap (*hardcoded*), status "2 hari lagi" tidak akan pernah berubah seiring berjalannya waktu.
   - *Penanganan*: Diimplementasikan algoritma selisih hari dinamis `Math.round((due - today) / (1000 * 60 * 60 * 24))` yang selalu dikalkulasikan ulang terhadap waktu sistem pengguna (`new Date()`).
3. **Ketersediaan Layanan Saat Server MySQL Nonaktif**:
   - *Temuan*: Jika layanan MySQL di XAMPP belum dijalankan, aplikasi web konvensional akan mengalami galat fatal (*fatal error / white screen*).
   - *Penanganan*: Diterapkan arsitektur *Dual-Layer Storage*, di mana frontend memiliki *failover engine* `localStorage` yang menyimpan data contoh (Mochi, Luna, Oreo) secara mandiri sehingga penguji dapat menjalankan aplikasi secara penuh langsung dari berkas `index.html`.

---

### 7. Evaluasi Kualitas Aplikasi

Evaluasi kualitas perangkat lunak mengacu pada standar ISO/IEC 25010 (*Software Product Quality*):

| Aspek Evaluasi | Hasil Evaluasi dan Pembuktian Kualitas |
| :--- | :--- |
| **Usability** | - Antarmuka menggunakan prinsip *Human-Computer Interaction (HCI)* modern dengan sistem umpan balik visual (*toast notification*, dialog konfirmasi, dan lencana warna status).<br>- Pengujian pada perangkat mobile (resolusi 375px - 768px) dan desktop (1080p - 4K) membuktikan tata letak responsif tanpa adanya elemen yang tumpang tindih (*horizontal overflow*). |
| **Reliability** | - Tidak ditemukan kegagalan fungsi (*runtime error*) saat input form dikosongkan atau diisi data acak berkat validasi berlapis.<br>- Mekanisme persistensi ganda memastikan data tidak hilang saat tab browser ditutup atau diperbarui (*reload*). |
| **Security** | - Password dienkripsi satu arah dengan `password_hash()` standar algoritma BCRYPT.<br>- Semua eksekusi query SQL pada layer backend memanfaatkan *PDO Prepared Statements* yang memitigasi celah serangan *SQL Injection* secara total.<br>- Validasi tipe data dan sanitasi karakter teks mencegah eksploitasi celah *Cross-Site Scripting (XSS)*. |
| **Maintainability** | - Kode sumber disusun secara modular dalam folder terpisah (`assets/css`, `assets/js`, `api`, `config`).<br>- Struktur penamaan variabel dan fungsi menggunakan konvensi bahasa Indonesia dan Inggris yang jelas, dilengkapi komentar dokumentasi teknis pada setiap modul berkas. |

---

### 8. Dokumentasi dan Demonstrasi Aplikasi

#### a. Dokumentasi yang Disertakan
1. **Dokumen Laporan Praktikum UAS**: Lembar jawaban resmi format STMIK IKMI Cirebon.
2. **Dokumentasi `README.md`**: Panduan lengkap arsitektur sistem, fitur, struktur folder, kredensial demo, dan tata cara instalasi.
3. **Berkas Skema `database.sql`**: Berkas SQL pembentuk tabel, relasi kunci asing (*Foreign Keys*), dan data awal pasien fiktif (*seed data*).
4. **Komentar Kode Sumber (*Inline Code Documentation*)**: Keterangan pada setiap method dan fungsi di seluruh berkas JavaScript dan PHP.

#### b. Tautan Repository atau Berkas Proyek
- Folder Proyek: `C:\xampp\htdocs\SHINEVET\`
- Berkas Utama: `index.html` dan `index.php`
- Repositori: `https://github.com/mahasiswa/petcare-animal-clinic` *(Dapat disesuaikan)*

#### c. Penjelasan Keputusan Teknis dan Hasil Demonstrasi
1. **Keputusan Pemilihan Arsitektur SPA Hybrid**:
   Pemilihan arsitektur SPA berbasis JavaScript murni yang didukung RESTful API PHP diambil guna memastikan sistem memiliki performa sangat responsif saat dioperasikan dokter hewan di lapangan tanpa jeda muat ulang halaman (*zero page flicker*), namun tetap memiliki kesiapan skalabilitas integrasi basis data relasional enterprise.
2. **Hasil Demonstrasi Alur Kerja**:
   - Seluruh alur kerja mulai dari registrasi klien, penambahan profil hewan kesayangan, pengajuan janji temu melalui wizard 3 langkah dengan validasi bentrok slot waktu, konfirmasi jadwal oleh admin klinik, integrasi WhatsApp otomatis, pencatatan rekam medis digital, hingga kalender vaksinasi dinamis telah berhasil diuji dan berfungsi secara optimal 100%.

---

## C. DAFTAR BERKAS YANG DIKUMPULKAN

1. **Kode Sumber Aplikasi**: Berkas HTML5, CSS3, JavaScript modular, dan PHP backend API (`c:\xampp\htdocs\SHINEVET\`).
2. **Dokumen Kebutuhan dan Rancangan Sistem**: Uraian kebutuhan fungsional & nonfungsional pada dokumen laporan.
3. **Diagram UML dan ERD**: Use Case Diagram, Activity Diagram, Sequence Diagram, Class Diagram, dan Entity Relationship Diagram.
4. **Dokumentasi Rancangan UI/UX**: Panduan desain antarmuka 9 tampilan utama dengan aset foto HD.
5. **Skenario dan Bukti Hasil Pengujian**: Tabel Black Box Testing dengan 10 skenario pengujian fungsional.
6. **Tautan Repository atau Berkas Aplikasi**: Tautan proyek lokal dan repositori Git.
7. **Dokumentasi dan Bahan Demonstrasi**: Berkas README.md dan kredensial akun uji coba.

---

## D. PERNYATAAN MAHASISWA

Saya menyatakan bahwa hasil pekerjaan yang dikumpulkan merupakan hasil pekerjaan saya sendiri sesuai dengan ketentuan ujian, norma akademik, dan petunjuk pengerjaan Ujian Akhir Semester mata kuliah Rekayasa Perangkat Lunak.

Cirebon, 11 November 2026  
Mahasiswa,  


**( .................................................... )**  
NIM: ..............................................  

---

## E. PENILAIAN DOSEN

| No. | Komponen Penilaian | Bobot | Nilai |
| :---: | :--- | :---: | :---: |
| 1 | Rancangan sistem: kebutuhan, UML, ERD, arsitektur, UI/UX | 25% | |
| 2 | Implementasi aplikasi | 25% | |
| 3 | Pengujian perangkat lunak | 20% | |
| 4 | Kualitas dan kesiapan aplikasi | 15% | |
| 5 | Dokumentasi, repository, demonstrasi, dan penjelasan teknis | 15% | |
| **Total** | | **100%** | |

**Nilai Akhir**: ........................................  

**Catatan Dosen**:  
............................................................................................................  
............................................................................................................  

Dosen Pengampu,  


**(Agus Bahtiar, M.Kom.)**  
